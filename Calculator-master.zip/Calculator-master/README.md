# Calculator
C# Simple Calculator using Windows Forms Application

  ![calc](https://user-images.githubusercontent.com/16005672/54432581-4bf82000-4732-11e9-8d02-05ac3efcb9d7.jpg)
